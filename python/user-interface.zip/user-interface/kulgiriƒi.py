import sys
import sqlite3
from PyQt5 import QtWidgets
class Pencere(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.set_connection()
        self.init__ui()
          
    def set_connection(self):
        connection=sqlite3.connect("database.db")
        self.cursor=connection.cursor()
        self.cursor.execute("Create Table If not exists üyeler(id TEXT,pw TEXT)")
        connection.commit()

    def login(self):
        id=self.id.text()
        pw=self.pw.text()

        self.cursor.execute("Select * From üyeler where id=? and pw=?",(id,pw))
        data=self.cursor.fetchall()

        if len(data)==0:
            self.writing_area.setText("tekrar dene")
        else:
            self.writing_area.setText("hoşgeldiniz "+id)


    def init__ui(self):
        self.id=QtWidgets.QLineEdit()
        self.pw=QtWidgets.QLineEdit()
        self.pw.setEchoMode(QtWidgets.QLineEdit.Password)#parola alanı gibi yapar

        self.giris=QtWidgets.QPushButton("giriş")
        self.writing_area=QtWidgets.QLabel("")

        v_box=QtWidgets.QVBoxLayout()
        v_box.addWidget(self.id)
        v_box.addWidget(self.pw)
        v_box.addWidget(self.writing_area)
        v_box.addStretch()
        v_box.addWidget(self.giris)
        
        h_box=QtWidgets.QHBoxLayout()
        h_box.addStretch()
        h_box.addLayout(v_box)
        h_box.addStretch()


        self.setLayout(h_box)
        self.setWindowTitle("KUL GİRİŞİ")

        self.giris.clicked.connect(self.login)

        self.show()


app=QtWidgets.QApplication(sys.argv)
pencere=Pencere()
sys.exit(app.exec_())