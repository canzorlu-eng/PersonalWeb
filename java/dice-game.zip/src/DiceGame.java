import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * This class represents a player
 */
class Player {
    private String name;
    private int score;

    public Player(String name) {
        this.name = name;
        this.score = 0;
    }

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }

    public void addScore(int points) {
        score += points;
    }

    public void loseAllPoints() {
        score = 0;
    }

    @Override
    public String toString() {
        return name;
    }
}

/**
 * This class for game.
 */
public class DiceGame {
    private List<Player> players;
    private int currentPlayerIndex;

    public DiceGame(List<String> playerNames) {
        players = new ArrayList<>();
        for (String name : playerNames) {
            players.add(new Player(name));
        }
        currentPlayerIndex = 0;
    }

    /**
     * Rolls two dice and updates the player's score
     */
    public void rollDice(int dice1, int dice2, BufferedWriter bwriter) throws IOException {
        Player currentPlayer = players.get(currentPlayerIndex);
        bwriter.write(currentPlayer.getName() + " threw " + dice1 + "-" + dice2);
        if (dice1 == 1 && dice2 == 1) {
            bwriter.write(". Game over " + currentPlayer.getName() + "!\n");
            currentPlayer.loseAllPoints();
            players.remove(currentPlayerIndex);
        } else if (dice1 == 1 || dice2 == 1) {
            bwriter.write(" and " + currentPlayer.getName() + "'s score is " + currentPlayer.getScore() + ".\n");
        } else {
            currentPlayer.addScore(dice1 + dice2);
            bwriter.write(" and " + currentPlayer.getName() + "'s score is " + currentPlayer.getScore() + ".\n");
        }
        if (players.size() == 1) {
            Player winner = players.get(0);
            bwriter.write(winner.getName() + " is the winner of the game with the score of " + winner.getScore() + ". Congratulations " + winner.getName() + "!");
        } else {
            currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
        }
    }

    /**
     * Skips the turn
     */
    public void skipTurn(BufferedWriter bwriter) throws IOException {
        Player currentPlayer = players.get(currentPlayerIndex);
        bwriter.write(currentPlayer.getName() + " skipped the turn and " + currentPlayer.getName() + "'s score is " + currentPlayer.getScore() + ".\n");
        currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
    }

    public static void main(String[] args) {
        String inputFile = args[0];
        String outputFile = args[1];

        try (BufferedReader br = new BufferedReader(new FileReader(inputFile));
             BufferedWriter bwriter = new BufferedWriter(new FileWriter(outputFile))) {

            int numPlayers = Integer.parseInt(br.readLine());
            List<String> playerNames = new ArrayList<>();
            String[] names = br.readLine().split(",");

            for (String name : names) {
                playerNames.add(name);
            }

            DiceGame game = new DiceGame(playerNames);
            String line;
            while ((line = br.readLine()) != null) {
                if (line.equals("0-0")) {
                    game.skipTurn(bwriter);
                } else {
                    String[] diceValues = line.split("-");
                    int dice1 = Integer.parseInt(diceValues[0]);
                    int dice2 = Integer.parseInt(diceValues[1]);
                    game.rollDice(dice1, dice2, bwriter);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
