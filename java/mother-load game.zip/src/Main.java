import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

class FileIn {
    /**
     * Reads the file at the given path and returns contents of it in a string array.
     *
     * @param path              Path to the file that is going to be read.
     * @param discardEmptyLines If true, discards empty lines with respect to trim; else, it takes all the lines from the file.
     * @param trim              Trim status; if true, trims (strip in Python) each line; else, it leaves each line as-is.
     * @return Contents of the file as a string array, returns null if there is not such a file or this program does not have sufficient permissions to read that file.
     */
    public static String[] readFile(String path, boolean discardEmptyLines, boolean trim) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(path));
            if (discardEmptyLines) {
                lines.removeIf(line -> line.trim().equals(""));
            }
            if (trim) {
                lines.replaceAll(String::trim);
            }
            return lines.toArray(new String[0]);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}

public class Main extends Application {
    private static final double WIDTH = 600;
    private static final double HEIGHT = 450;
    private static final double CELL_SIZE = 30;

    private ImageView player;
    private Set<KeyCode> keysPressed = new HashSet<>();

    private Image leftImage;
    private Image rightImage;
    private Image downImage;
    private Image upImage;
    private Image topImage;
    private Image obstacleImage;
    private Image lavaImage;
    private Image soilImage;
    private Image amazoniteImage;
    private Image bronziumImage;
    private Image diamondImage;

    private double fuel = 9999.999;
    private int haul = 0;
    private int money = 0;
    private static int bronziumWorth;
    private static int diamondWorth;
    private static int amazoniteWorth;

    private static int bronziumWeight;
    private static int diamondWeight;
    private static int amazoniteWeight;

    private Text fuelText;
    private Text haulText;
    private Text moneyText;
    private boolean gravityEnabled = true;

    @Override
    public void start(Stage primaryStage) {
        Group root = new Group();
        Scene scene = new Scene(root, WIDTH, HEIGHT, Color.BLUE); // blue for background
        primaryStage.setScene(scene);

        // Creating a blue background for the entire scene
        Rectangle background = new Rectangle(0, 0, WIDTH, HEIGHT);
        background.setFill(Color.BLUE); // Make the whole background blue

        root.getChildren().add(background); // Add it to the root group, so it's at the back

        // Yönler için resimler
        leftImage = new Image(getClass().getResource("assets/drill/drill_01.png").toString());
        rightImage = new Image(getClass().getResource("assets/drill/drill_55.png").toString());
        downImage = new Image(getClass().getResource("assets/drill/drill_45.png").toString());
        upImage = new Image(getClass().getResource("assets/drill/drill_25.png").toString());
        topImage = new Image(getClass().getResource("assets/underground/top_01.png").toString());
        obstacleImage = new Image(getClass().getResource("assets/underground/obstacle_01.png").toString());

        lavaImage = new Image(getClass().getResource("assets/underground/lava_01.png").toString());
        soilImage = new Image(getClass().getResource("assets/underground/soil_01.png").toString());
        amazoniteImage = new Image(getClass().getResource("assets/underground/valuable_amazonite.png").toString());
        bronziumImage = new Image(getClass().getResource("assets/underground/valuable_bronzium.png").toString());
        diamondImage = new Image(getClass().getResource("assets/underground/valuable_diamond.png").toString());

        player = new ImageView(leftImage);
        player.setFitWidth(CELL_SIZE);
        player.setFitHeight(CELL_SIZE);

        player.setX(WIDTH  - player.getFitWidth());
        player.setY(HEIGHT/10 - player.getFitHeight()/2);

        // Çim zemini oluşturmak için döngü
        for (double x = 0; x < WIDTH; x += CELL_SIZE) {
            ImageView grass = new ImageView(topImage);
            grass.setFitWidth(CELL_SIZE);
            grass.setFitHeight(CELL_SIZE);
            grass.setX(x);
            grass.setY(90 - grass.getFitHeight());
            root.getChildren().add(grass);
        }

        // Sahne kenarlarını oluşturan engeller
        for (double x = 0; x < WIDTH; x += CELL_SIZE) {
            ImageView obstacle = new ImageView(obstacleImage);
            obstacle.setFitWidth(CELL_SIZE);
            obstacle.setFitHeight(CELL_SIZE);
            obstacle.setX(x);
            obstacle.setY(HEIGHT - obstacle.getFitHeight());
            root.getChildren().add(obstacle);
        }

        for (double y = 90; y < HEIGHT; y += CELL_SIZE) {
            ImageView obstacle = new ImageView(obstacleImage);
            obstacle.setFitWidth(CELL_SIZE);
            obstacle.setFitHeight(CELL_SIZE);
            obstacle.setX(0);
            obstacle.setY(y);
            root.getChildren().add(obstacle);
        }

        for (double y = 90; y < HEIGHT; y += CELL_SIZE) {
            ImageView obstacle = new ImageView(obstacleImage);
            obstacle.setFitWidth(CELL_SIZE);
            obstacle.setFitHeight(CELL_SIZE);
            obstacle.setX(WIDTH - CELL_SIZE);
            obstacle.setY(y);
            root.getChildren().add(obstacle);
        }


        Random random = new Random();
        // Önceden tanımlanmış değerli kaynakları yerleştirme
        placeUniqueTile(root, lavaImage, random, 1, WIDTH, HEIGHT);
        placeUniqueTile(root, amazoniteImage, random, 1, WIDTH, HEIGHT);
        placeUniqueTile(root, bronziumImage, random, 1, WIDTH, HEIGHT);
        placeUniqueTile(root, diamondImage, random, 1, WIDTH, HEIGHT);

        // Oyun alanındaki zemin katmanlarını rastgele oluşturma

        for (double x = CELL_SIZE; x < WIDTH - CELL_SIZE; x += CELL_SIZE) {
            for (double y = 90; y < HEIGHT - CELL_SIZE; y += CELL_SIZE) {
                ImageView tile;
                double randValue = random.nextDouble(); // [0,1] arası rastgele değer

                if (randValue < 0.8) {
                    tile = new ImageView(soilImage);
                } else if (randValue < 0.85) {
                    tile = new ImageView(lavaImage);
                } else if (randValue < 0.95) {
                    tile = new ImageView(amazoniteImage);
                } else if (randValue < 0.975) {
                    tile = new ImageView(bronziumImage);
                } else {
                    tile = new ImageView(diamondImage);
                }

                tile.setFitWidth(CELL_SIZE);
                tile.setFitHeight(CELL_SIZE);
                tile.setX(x);
                tile.setY(y);
                root.getChildren().add(tile);
            }
        }


        // Oyuncu kontrolü için olaylar
        // Event listener for key presses to move the player
        scene.setOnKeyPressed(event -> {
            KeyCode keyCode = event.getCode();
            keysPressed.add(event.getCode());
            double newX = player.getX();
            double newY = player.getY();

            // Determine the new position based on the key pressed
            if (keyCode == KeyCode.LEFT) {
                newX -= CELL_SIZE;
                player.setImage(leftImage);
            } else if (keyCode == KeyCode.RIGHT) {
                newX += CELL_SIZE;
                player.setImage(rightImage);
            } else if (keyCode == KeyCode.DOWN) {
                newY += CELL_SIZE;
                player.setImage(downImage);
            } else if (keyCode == KeyCode.UP) {
                // Yukarı hareket için kontrol: Üstteki hücre boş mu
                if (isTileEmpty(root, player.getX(), player.getY() - CELL_SIZE)) {
                    newY -= CELL_SIZE;
                    player.setImage(upImage);

                }
            }

            // Check if the new position would collide with an obstacle
            if (!isObstacleTile(root, newX, newY)) {
                // If not, move the player
                player.setX(newX);
                player.setY(newY);
                fuel -= 100;

                // Değerli madde kontrolü ve güncellemesi
                checkValuable(newX, newY, root);
                // Call the checkAndColorTile method to change the tile's color if necessary
                checkAndColorTile(newX, newY, root);



            }
        });




        scene.setOnKeyReleased(event -> keysPressed.remove(event.getCode()));

        // Yakıt ve diğer bilgiler için metinler
        fuelText = new Text(10, 20, "fuel: " + String.format("%.3f", fuel));
        haulText = new Text(10, 40, "haul: " + haul);
        moneyText = new Text(10, 60, "money: " + money);
        root.getChildren().addAll(player, fuelText, haulText, moneyText);


        AnimationTimer gameLoop = new AnimationTimer() {
            @Override
            public void handle(long now) {
                update(root);
            }
        };


        primaryStage.setTitle("HU-load");
        primaryStage.setScene(scene);
        primaryStage.show();
        AnimationTimer gravityTimer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                if (!keysPressed.contains(KeyCode.UP)) {
                    double currentX = player.getX();
                    double currentY = player.getY();
                    double newY = currentY + CELL_SIZE; // Bir hücre aşağıya kaydır

                    // Eğer aşağıda hücre boşsa oyuncuyu aşağıya hareket ettir
                    if (isTileEmpty(root, currentX, newY)) {
                        player.setY(newY);
                    }
                }
            }
        };

        gameLoop.start();
        gravityTimer.start();
    }

    private void checkValuable(double x, double y, Group root) {
        // Belirli bir koordinatta hangi madde olduğunu kontrol eder
        for (int i = 0; i < root.getChildren().size(); i++) {
            if (root.getChildren().get(i) instanceof ImageView) {
                ImageView imageView = (ImageView) root.getChildren().get(i);
                if (imageView.getX() == x && imageView.getY() == y) {
                    Image image = imageView.getImage();

                    if (image.equals(bronziumImage)) {
                        money += bronziumWorth; // Money'yi Bronzium'un değeri kadar artır
                        haul += bronziumWeight; // Haul'u Bronzium'un ağırlığı kadar artır
                    } else if (image.equals(diamondImage)) {
                        money += diamondWorth; // Money'yi Diamond'un değeri kadar artır
                        haul += diamondWeight; // Haul'u Diamond'un ağırlığı kadar artır
                    } else if (image.equals(amazoniteImage)) {
                        money += amazoniteWorth; // Money'yi Amazonite'un değeri kadar artır
                        haul += amazoniteWeight; // Haul'u Amazonite'un ağırlığı kadar artır
                    }
                }
            }
        }
    }

    private boolean isTileEmpty(Group root, double x, double y) {
        // Verilen koordinatta herhangi bir nesne olup olmadığını kontrol eder
        for (int i = 0; i < root.getChildren().size(); i++) {
            if (root.getChildren().get(i) instanceof ImageView) {
                ImageView imageView = (ImageView) root.getChildren().get(i);
                if (imageView.getX() == x && imageView.getY() == y) {
                    return false; // Orada bir nesne var, bu yüzden boş değil
                }
            }
        }
        return true; // Orada herhangi bir nesne yoksa, boş
    }


    private void placeUniqueTile(Group root, Image image, Random random, int count, double width, double height) {
        // Değerli kaynaklardan en az bir tane olacak şekilde yerleştirmek için
        int placedCount = 0;
        while (placedCount < count) {
            double x = CELL_SIZE * (random.nextInt((int) ((width - 2 * CELL_SIZE) / CELL_SIZE)) + 1);
            double y = 90 + CELL_SIZE * (random.nextInt((int) ((height - 2 * CELL_SIZE - 90) / CELL_SIZE)) + 1);

            if (!isTileOccupied(root, x, y) && !isObstacleAhead(x, y,root)) {
                ImageView tile = new ImageView(image);
                tile.setFitWidth(CELL_SIZE);
                tile.setFitHeight(CELL_SIZE);
                tile.setX(x);
                tile.setY(y);
                root.getChildren().add(tile);
                placedCount++;
            }
        }
    }

    private boolean isTileOccupied(Group root, double x, double y) {
        // Belirli bir koordinatta zaten bir eleman olup olmadığını kontrol etmek için
        for (int i = 0; i < root.getChildren().size(); i++) {
            if (root.getChildren().get(i) instanceof ImageView) {
                ImageView imageView = (ImageView) root.getChildren().get(i);
                if (imageView.getX() == x && imageView.getY() == y) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isObstacleAhead(double x, double y,Group root) {
        // Önünde engel olup olmadığını kontrol etmek için
        for (double i = 0; i <= CELL_SIZE; i += CELL_SIZE) {
            if (isObstacleTile(root, x + i, y)) {
                return true;
            }
        }
        return false;
    }

    private boolean isObstacleTile(Group root, double x, double y) {
        // Belirli bir koordinattaki imageın bir engel olup olmadığını kontrol etmek için
        for (int i = 0; i < root.getChildren().size(); i++) {
            if (root.getChildren().get(i) instanceof ImageView) {
                ImageView imageView = (ImageView) root.getChildren().get(i);
                if (imageView.getX() == x && imageView.getY() == y && imageView.getImage().equals(obstacleImage)) {
                    return true;
                }
            }
        }
        return false;
    }

    private void checkAndColorTile(double x, double y,Group root) {
        for (int i = 0; i < root.getChildren().size(); i++) {
            if (root.getChildren().get(i) instanceof ImageView) {
                ImageView imageView = (ImageView) root.getChildren().get(i);
                if (imageView.getX() == x && imageView.getY() == y) {

                    Image currentImage = imageView.getImage();
                    if (currentImage.equals(soilImage) ||
                            currentImage.equals(diamondImage) ||
                            currentImage.equals(amazoniteImage) ||
                            currentImage.equals(bronziumImage) ||
                            currentImage.equals(topImage)){

                        // Hücreyi turuncuya boyamak için dikdörtgen
                        Rectangle highlight = new Rectangle(x, y, CELL_SIZE, CELL_SIZE);
                        highlight.setFill(Color.ORANGE);
                        root.getChildren().add(highlight);
                        player.toFront();
                        // Hücreyi boyadıktan sonra orijinal nesneyi kaldır
                        root.getChildren().remove(imageView);
                        break;
                    }
                }
            }
        }
    }
    // Lava kontrolü için yeni bir yardımcı fonksiyon
    private boolean isLavaTile(Group root, double x, double y) {
        // Verilen koordinatın lav olup olmadığını kontrol eder
        for (int i = 0; i < root.getChildren().size(); i++) {
            if (root.getChildren().get(i) instanceof ImageView) {
                ImageView imageView = (ImageView) root.getChildren().get(i);
                if (imageView.getX() == x && imageView.getY() == y && imageView.getImage().equals(lavaImage)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isGameOver = false;
    private boolean isLavaGameOver = false;
    private void update(Group root) {
        // Yakıt tüketimi
        fuel -= 0.027;

        // Oyuncuyu sahne sınırlarında tutmak
        double minX = 0;
        double maxX = WIDTH - CELL_SIZE;
        double minY = 0;
        double maxY = HEIGHT - 2*CELL_SIZE;


        if (player.getX() < minX) {
            player.setX(minX);
        } else if (player.getX() > maxX) {
            player.setX(maxX);
        }

        if (player.getY() < minY) {
            player.setY(minY);
        } else if (player.getY() > maxY) {
            player.setY(maxY);
        }

        // Metinler güncel
        fuelText.setText("fuel: " + String.format("%.3f", fuel));
        haulText.setText("haul: " + haul);
        moneyText.setText("money: " + money);

        // Oyun bittiğinde kontrol
        if (fuel <= 0 && !isGameOver) {
            isGameOver=true;
            gameOver(Color.GREEN,isLavaGameOver);
        }
        if (isLavaTile(root, player.getX(), player.getY()) && !isGameOver) {
            isGameOver = true;
            isLavaGameOver=true;
            gameOver(Color.RED,isLavaGameOver); // Kırmızı arka plan için
        }
    }



    private void gameOver(Color backgroundColor,boolean isLavaGameOver) {
        // Oyun bittiğinde mesaj göstermek için
        Group gameOverGroup = new Group();
        Rectangle background = new Rectangle(0, 0, WIDTH, HEIGHT);
        background.setFill(backgroundColor); // Arka plan rengi
        gameOverGroup.getChildren().add(background);

        // Game Over mesajını oluşturur
        Text gameOverText = new Text(WIDTH / 2 - 80, HEIGHT / 2 - 30, "Game Over!");
        gameOverText.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        gameOverText.setFill(Color.WHITE);

        gameOverGroup.getChildren().add(gameOverText);

        if (!isLavaGameOver) {
            Text moneyDisplay = new Text(WIDTH / 2 - 80, HEIGHT / 2 + 10, "Collected Money: " + money);
            moneyDisplay.setFont(Font.font("Arial", 24));
            moneyDisplay.setFill(Color.WHITE);
            gameOverGroup.getChildren().add(moneyDisplay);
        }

        Scene gameOverScene = new Scene(gameOverGroup, WIDTH, HEIGHT);
        Stage gameOverStage = new Stage();
        gameOverStage.setTitle("Game Over");
        gameOverStage.setScene(gameOverScene);
        gameOverStage.show();

        Stage mainStage = (Stage) fuelText.getScene().getWindow();
        mainStage.close(); // Ana sahneyi kapat
    }


    public static void main(String[] args) {

        String[] input = FileIn.readFile("src/assets/atributes_of_valuables.txt", true, true);
        for (int i=1;i<input.length;i++){
            String line=input[i];
            String[] parts=line.split("\t");
            if (parts[0].equals("Bronzium")){
                bronziumWorth=Integer.parseInt(parts[1]);
                bronziumWeight=Integer.parseInt(parts[2]);
            }
            if (parts[0].equals("Diamond")){
                diamondWorth=Integer.parseInt(parts[1]);
                diamondWeight=Integer.parseInt(parts[2]);
            }
            if (parts[0].equals("Amazonite")){
                amazoniteWorth=Integer.parseInt(parts[1]);
                amazoniteWeight=Integer.parseInt(parts[2]);
            }
        }
        launch(args);
    }
}