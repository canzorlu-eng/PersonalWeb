import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

class FileIn {
    public static String[] readFile(String path, boolean discardEmptyLines, boolean trim) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(path));
            if (discardEmptyLines) {
                lines.removeIf(line -> line.trim().equals(""));
            }
            if (trim) {
                lines.replaceAll(String::trim);
            }
            return lines.toArray(new String[0]);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}

class FileOut {
    public static void writeToFile(String path, String content, boolean append, boolean newLine) {
        PrintStream ps = null;
        try {
            ps = new PrintStream(new FileOutputStream(path, append));
            ps.print(content + (newLine ? "\n" : ""));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (ps != null) {
                ps.flush();
                ps.close();
            }
        }
    }
}
class GymMealMachine {
    private static final int ROWS = 6;
    private static final int COLUMNS = 4;
    private static final int SLOT_CAPACITY = 10;
    private String[][][] gmmArray;
    public GymMealMachine() {
        gmmArray = new String[ROWS][COLUMNS][SLOT_CAPACITY];
    }
    public String[][][] getGmmArray() {
        return gmmArray;
    }











    public boolean es(String product){
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLUMNS; j++) {
                if ((gmmArray[i][j][0])!=null){
                    if (product.equals(gmmArray[i][j][0])){
                        for (int k = 0; k < gmmArray[0][0].length; k++) {
                            if (gmmArray[i][j][k] == null) {
                                gmmArray[i][j][k] = product;
                                return false;
                            }
                        }
                    }
                }

            }
        }
        return true;
    }

    public boolean doluMu(){
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLUMNS; j++) {
                for (int k = 0; k < SLOT_CAPACITY; k++) {
                    if (gmmArray[i][j][k]==null){
                        return false;
                    }
                }
            }
        }
        return true;
    }


    public int fill(String[] productInfo,String[] args) {

        for (String product:productInfo){
            if(doluMu()){
                if (es(product)) {
                    String[] forProductName = product.split("\t");
                    String productName = forProductName[0];
                    String bas = String.format("INFO: There is no available place to put %s", productName);
                    FileOut.writeToFile(args[2], bas, true, true);
                }
                FileOut.writeToFile(args[2], "INFO: The machine is full!", true, true);
                return -1;
            }


            boolean b=true;
            if (es(product)){
                outerLoop:
                for (int i = 0; i < ROWS; i++) {
                    for (int j = 0; j < COLUMNS; j++) {
                        if (gmmArray[i][j][0]==null){
                            gmmArray[i][j][0]=product;
                            b=false;
                            break outerLoop;
                        }
                    }
                }
                if (b){
                    String[] forProductName=product.split("\t");
                    String productName=forProductName[0];
                    //INFO: There is no available place to put Protein Bar
                    String bas = String.format("INFO: There is no available place to put %s",productName);
                    FileOut.writeToFile(args[2], bas, true, true);
                }
            }

        }


        return 0;
    }


    public double calculateCalorie(double protein,double carb,double fat){
        double calorie=(4*protein)+(4*carb)+(9*fat);
        return calorie;
    }
    public int purchase(String line,String type,String choiceType, int value,String[] money,String[] productList,String[] args) {
        int change = 0;
        int moneys=0;
        for (String m:money) {
            moneys += Integer.parseInt(m);
        }
        if (choiceType.equals("NUMBER")){
            if (value<25){
                String choice=gmmArray[value/4][value%4][0];
                for (int k = 1; k < gmmArray[0][0].length; k++) {
                    if (gmmArray[value/4][value%4][k]==null){
                        if (gmmArray[value / 4][value % 4][k-1]!=null){
                            String[] satir = gmmArray[value / 4][value % 4][k-1].split("\t");
                            int price=Integer.parseInt(satir[1]);
                            change = moneys-price;
                            String baski = String.format("INPUT: %s ",line);
                            FileOut.writeToFile(args[2],baski , true, true);
                            if (change<0){
                                FileOut.writeToFile(args[2],"INFO: Insufficient money, try again with more money." , true, true);
                                String bas = String.format("RETURN: Returning your change: %d TL",moneys);
                                FileOut.writeToFile(args[2],bas , true, true);

                            }
                            else {
                                String baski1 = String.format("PURCHASE: You have bought one %s",satir[0]);
                                FileOut.writeToFile(args[2],baski1 , true, true);
                                String baski2 = String.format("RETURN: Returning your change: %d TL",change);
                                FileOut.writeToFile(args[2],baski2 , true, true);
                                gmmArray[value / 4][value % 4][k - 1] = null;
                            }
                            return  5;
                        }
                    }
                }

                if (gmmArray[value / 4][value % 4][0]!=null) {
                    String[] satir = gmmArray[value / 4][value % 4][0].split("\t");
                    int price = Integer.parseInt(satir[1]);
                    change = moneys - price;



                    String baski = String.format("INPUT: %s ",line);
                    FileOut.writeToFile(args[2],baski , true, true);
                    if (change<0){
                        FileOut.writeToFile(args[2],"INFO: Insufficient money, try again with more money." , true, true);
                        String bas = String.format("RETURN: Returning your change: %d TL",moneys);
                        FileOut.writeToFile(args[2],bas , true, true);

                    }
                    else {
                        String baski1 = String.format("PURCHASE: You have bought one %s",satir[0]);
                        FileOut.writeToFile(args[2],baski1 , true, true);
                        String baski2 = String.format("RETURN: Returning your change: %d TL",change);
                        FileOut.writeToFile(args[2],baski2 , true, true);
                        gmmArray[value / 4][value % 4][9] = null;
                    }
                }
                if (gmmArray[value/4][value%4][0]==null){
                    String baski = String.format("INPUT: %s ",line);
                    FileOut.writeToFile(args[2],baski , true, true);
                    FileOut.writeToFile(args[2],"INFO: This slot is empty, your money will be returned." , true, true);
                    String bas = String.format("RETURN: Returning your change: %d TL",moneys);
                    FileOut.writeToFile(args[2],bas , true, true);
                }
            }
            else{
                String baski = String.format("INPUT: %s ",line);
                FileOut.writeToFile(args[2],baski , true, true);
                FileOut.writeToFile(args[2],"INFO: Number cannot be accepted. Please try again with another number." , true, true);
                String bas = String.format("RETURN: Returning your change: %d TL",moneys);
                FileOut.writeToFile(args[2],bas , true, true);

            }
        }







        if (choiceType.equals("CARB")) {
            outerLoop:
            for (int i = 0; i < gmmArray.length; i++) {
                for (int j = 0; j < gmmArray[0].length; j++) {
                    if (gmmArray[i][j][0]!=null){
                        if (gmmArray[i][j][0]!=null){
                            String[] satir = gmmArray[i][j][0].split("\t");
                            String[] nutritions = satir[2].split(" ");
                            double carb = Double.parseDouble(nutritions[1]);
                            if (carb >= (value - 5) && carb <= (value + 5)) {

                                for (int k = 0; k < gmmArray[0][0].length; k++) {
                                    if (gmmArray[i][j][k] == null) {
                                        int price = Integer.parseInt(satir[1]);
                                        change = moneys - price;
                                        String baski = String.format("INPUT: %s ",line);
                                        FileOut.writeToFile(args[2],baski , true, true);
                                        if (change<0){
                                            FileOut.writeToFile(args[2],"INFO: Insufficient money, try again with more money." , true, true);
                                            String bas = String.format("RETURN: Returning your change: %d TL",moneys);
                                            FileOut.writeToFile(args[2],bas , true, true);
                                        }
                                        else {
                                            String baski1 = String.format("PURCHASE: You have bought one %s",satir[0]);
                                            FileOut.writeToFile(args[2],baski1 , true, true);
                                            String baski2 = String.format("RETURN: Returning your change: %d TL",change);
                                            FileOut.writeToFile(args[2],baski2 , true, true);
                                            gmmArray[i][j][k - 1] = null;
                                        }
                                        return 5;
                                        //break outerLoop;
                                    }
                                }
                                int price = Integer.parseInt(satir[1]);
                                change = moneys - price;
                                String baski = String.format("INPUT: %s ",line);
                                FileOut.writeToFile(args[2],baski , true, true);
                                if (change<0){
                                    FileOut.writeToFile(args[2],"INFO: Insufficient money, try again with more money." , true, true);
                                    String bas = String.format("RETURN: Returning your change: %d TL",moneys);
                                    FileOut.writeToFile(args[2],bas , true, true);
                                }
                                else {
                                    String baski1 = String.format("PURCHASE: You have bought one %s",satir[0]);
                                    FileOut.writeToFile(args[2],baski1 , true, true);
                                    String baski2 = String.format("RETURN: Returning your change: %d TL",change);
                                    FileOut.writeToFile(args[2],baski2 , true, true);
                                    gmmArray[i][j][9] = null;
                                }
                                return 5;
                                //break outerLoop;
                            }
                        }

                    }
                }
            }

            String baski = String.format("INPUT: %s ",line);
            FileOut.writeToFile(args[2],baski , true, true);
            FileOut.writeToFile(args[2],"INFO: Product not found, your money will be returned." , true, true);
            String bas = String.format("RETURN: Returning your change: %d TL",moneys);
            FileOut.writeToFile(args[2],bas , true, true);
        }
        if (choiceType.equals("PROTEIN")) {
            outerLoop:
            for (int i = 0; i < gmmArray.length; i++) {
                for (int j = 0; j < gmmArray[0].length; j++) {
                    if (gmmArray[i][j][0]!=null){
                        String[] satir = gmmArray[i][j][0].split("\t");
                        String[] nutritions = satir[2].split(" ");
                        double protein = Double.parseDouble(nutritions[0]);
                        if (protein >= (value - 5)) {
                            if (protein <= (value + 5)) {
                                for (int k = 0; k < gmmArray[0][0].length; k++) {
                                    if (gmmArray[i][j][k] == null) {
                                        int price = Integer.parseInt(satir[1]);
                                        change = moneys - price;
                                        String baski = String.format("INPUT: %s ",line);
                                        FileOut.writeToFile(args[2],baski , true, true);
                                        if (change<0){
                                            FileOut.writeToFile(args[2],"INFO: Insufficient money, try again with more money." , true, true);
                                            String bas = String.format("RETURN: Returning your change: %d TL",moneys);
                                            FileOut.writeToFile(args[2],bas , true, true);

                                        }
                                        else {
                                            String baski1 = String.format("PURCHASE: You have bought one %s",satir[0]);
                                            FileOut.writeToFile(args[2],baski1 , true, true);
                                            String baski2 = String.format("RETURN: Returning your change: %d TL",change);
                                            FileOut.writeToFile(args[2],baski2 , true, true);
                                            gmmArray[i][j][k - 1] = null;
                                        }
                                        return 5;
                                        //break outerLoop;
                                    }

                                }
                                int price = Integer.parseInt(satir[1]);
                                change = moneys - price;
                                String baski = String.format("INPUT: %s ",line);
                                FileOut.writeToFile(args[2],baski , true, true);
                                if (change<0){
                                    FileOut.writeToFile(args[2],"INFO: Insufficient money, try again with more money." , true, true);
                                    String bas = String.format("RETURN: Returning your change: %d TL",moneys);
                                    FileOut.writeToFile(args[2],bas , true, true);

                                }
                                else {
                                    String baski1 = String.format("PURCHASE: You have bought one %s",satir[0]);
                                    FileOut.writeToFile(args[2],baski1 , true, true);
                                    String baski2 = String.format("RETURN: Returning your change: %d TL",change);
                                    FileOut.writeToFile(args[2],baski2 , true, true);
                                    gmmArray[i][j][9] = null;
                                }
                                return 5;
                                //break outerLoop;
                            }
                        }
                    }

                }
            }
            String baski = String.format("INPUT: %s ",line);
            FileOut.writeToFile(args[2],baski , true, true);
            FileOut.writeToFile(args[2],"INFO: Product not found, your money will be returned." , true, true);
            String bas = String.format("RETURN: Returning your change: %d TL",moneys);
            FileOut.writeToFile(args[2],bas , true, true);
        }
        if (choiceType.equals("FAT")){
            outerLoop:
            for (int i = 0; i < gmmArray.length; i++) {
                for (int j = 0; j < gmmArray[0].length; j++) {
                    if (gmmArray[i][j][0]!=null){
                        String[] satir=gmmArray[i][j][0].split("\t");
                        String[] nutritions=satir[2].split(" ");
                        double fat=Double.parseDouble(nutritions[2]);
                        if (fat>=(value-5)){
                            if (fat<=(value+5)){
                                for (int k = 0; k < gmmArray[0][0].length; k++) {
                                    if (gmmArray[i][j][k]==null){

                                        int price=Integer.parseInt(satir[1]);
                                        change = moneys-price;

                                        String baski = String.format("INPUT: %s ",line);
                                        FileOut.writeToFile(args[2],baski , true, true);
                                        if (change<0){
                                            FileOut.writeToFile(args[2],"INFO: Insufficient money, try again with more money." , true, true);
                                            String bas = String.format("RETURN: Returning your change: %d TL",moneys);
                                            FileOut.writeToFile(args[2],bas , true, true);

                                        }
                                        else {
                                            String baski1 = String.format("PURCHASE: You have bought one %s",satir[0]);
                                            FileOut.writeToFile(args[2],baski1 , true, true);
                                            String baski2 = String.format("RETURN: Returning your change: %d TL",change);
                                            FileOut.writeToFile(args[2],baski2 , true, true);
                                            gmmArray[i][j][k - 1] = null;
                                        }
                                        return 5;
                                        //break outerLoop;
                                    }
                                }
                                int price=Integer.parseInt(satir[1]);
                                change = moneys-price;

                                String baski = String.format("INPUT: %s ",line);
                                FileOut.writeToFile(args[2],baski , true, true);
                                if (change<0){
                                    FileOut.writeToFile(args[2],"INFO: Insufficient money, try again with more money." , true, true);
                                    String bas = String.format("RETURN: Returning your change: %d TL",moneys);
                                    FileOut.writeToFile(args[2],bas , true, true);

                                }
                                else {
                                    String baski1 = String.format("PURCHASE: You have bought one %s",satir[0]);
                                    FileOut.writeToFile(args[2],baski1 , true, true);
                                    String baski2 = String.format("RETURN: Returning your change: %d TL",change);
                                    FileOut.writeToFile(args[2],baski2 , true, true);
                                    gmmArray[i][j][9] = null;
                                }
                                return 5;
                                //break outerLoop;
                            }
                        }
                    }

                }
            }
            String baski = String.format("INPUT: %s ",line);
            FileOut.writeToFile(args[2],baski , true, true);
            FileOut.writeToFile(args[2],"INFO: Product not found, your money will be returned." , true, true);
            String bas = String.format("RETURN: Returning your change: %d TL",moneys);
            FileOut.writeToFile(args[2],bas , true, true);
        }
        if (choiceType.equals("CALORIE")) {
            int calorie=0;
            outerLoop:
            for (int i = 0; i < gmmArray.length; i++) {
                for (int j = 0; j < gmmArray[0].length; j++) {
                    if (gmmArray[i][j][0]!=null){
                        String[] satir = gmmArray[i][j][0].split("\t");
                        String[] nutritions = satir[2].split(" ");
                        double carb=Double.parseDouble(nutritions[1]);
                        double protein = Double.parseDouble(nutritions[0]);
                        double fat=Double.parseDouble(nutritions[2]);
                        calorie=(int) Math.round(calculateCalorie(protein,carb,fat));
                        if (calorie>=(value-5)){
                            if (calorie<=(value+5)){
                                for (int k = 0; k < gmmArray[0][0].length; k++) {
                                    if (gmmArray[i][j][k]==null){
                                        int price=Integer.parseInt(satir[1]);
                                        change = moneys-price;

                                        String baski = String.format("INPUT: %s ",line);
                                        FileOut.writeToFile(args[2],baski , true, true);
                                        if (change<0){
                                            FileOut.writeToFile(args[2],"INFO: Insufficient money, try again with more money." , true, true);
                                            String bas = String.format("RETURN: Returning your change: %d TL",moneys);
                                            FileOut.writeToFile(args[2],bas , true, true);

                                        }
                                        else {
                                            String baski1 = String.format("PURCHASE: You have bought one %s",satir[0]);
                                            FileOut.writeToFile(args[2],baski1 , true, true);
                                            String baski2 = String.format("RETURN: Returning your change: %d TL",change);
                                            FileOut.writeToFile(args[2],baski2 , true, true);
                                            gmmArray[i][j][k - 1] = null;
                                        }
                                        return 5;

                                        //break outerLoop;
                                    }
                                }
                                int price=Integer.parseInt(satir[1]);
                                change = moneys-price;

                                String baski = String.format("INPUT: %s ",line);
                                FileOut.writeToFile(args[2],baski , true, true);
                                if (change<0){
                                    FileOut.writeToFile(args[2],"INFO: Insufficient money, try again with more money." , true, true);
                                    String bas = String.format("RETURN: Returning your change: %d TL",moneys);
                                    FileOut.writeToFile(args[2],bas , true, true);

                                }
                                else {
                                    String baski1 = String.format("PURCHASE: You have bought one %s",satir[0]);
                                    FileOut.writeToFile(args[2],baski1 , true, true);
                                    String baski2 = String.format("RETURN: Returning your change: %d TL",change);
                                    FileOut.writeToFile(args[2],baski2 , true, true);
                                    gmmArray[i][j][9] = null;
                                }
                                return 5;

                                //break outerLoop;
                            }
                        }
                    }
                }
            }


            String baski = String.format("INPUT: %s ",line);
            FileOut.writeToFile(args[2],baski , true, true);
            FileOut.writeToFile(args[2],"INFO: Product not found, your money will be returned." , true, true);
            String bas = String.format("RETURN: Returning your change: %d TL",moneys);
            FileOut.writeToFile(args[2],bas , true, true);

        }
        return change;
    }
    public int leftover(int i,int j){
        for (int k = 0; k < gmmArray[0][0].length; k++) {
            if (gmmArray[i][j][k]==null){
                return k;
            }
        }
        return 10;
    }
}

public class Main {
    public static void main(String[] args) {
        //Note that args[0] is the first command-line-arguments as opposed to Python's one-indexed (argv[1]) approach.
        String[] productContent = FileIn.readFile(args[0], false, false); // Reads the file as it is without discarding or trimming anything and stores it in string array namely content.
        String[] purchaseContent = FileIn.readFile(args[1], false, false);
        FileOut.writeToFile(args[2], "", false, false); //For reinitializing the file, it is not necessary but good practice for making sure about there is no leftover.

        GymMealMachine gymMealMachine = new GymMealMachine();
        String[][][] gmmArray = gymMealMachine.getGmmArray();
        gymMealMachine.fill(productContent,args);


        FileOut.writeToFile(args[2], "-----Gym Meal Machine-----", true, true);
        StringBuilder linBuilder = new StringBuilder();
        int itemCount1 = 0;

        for (int i = 0; i < gmmArray.length; i++) {
            for (int j = 0; j < gmmArray[0].length; j++) {
                if (gmmArray[i][j][0] == null) {
                    linBuilder.append("___(0, 0)___");
                } else {
                    String[] isimIcin = gmmArray[i][j][0].split("\t");
                    String productName = isimIcin[0];
                    String[] nutritions = isimIcin[2].split(" ");
                    double protein = Double.parseDouble(nutritions[0]);
                    double carb = Double.parseDouble(nutritions[1]);
                    double fat = Double.parseDouble(nutritions[2]);
                    double calorie = gymMealMachine.calculateCalorie(protein, carb, fat);
                    int calorie1 = (int) Math.round(calorie);
                    int leftovers = gymMealMachine.leftover(i, j);
                    String itemString = String.format("%s(%d, %d)___", productName, calorie1, leftovers);
                    linBuilder.append(itemString);
                }

                itemCount1++;
                // Satır sonuna ulaşıldığında veya son elemana ulaşıldığında, satırı dosyaya yaz ve satırı temizle
                if (itemCount1 % 4 == 0 || (i == gmmArray.length - 1 && j == gmmArray[0].length - 1)) {
                    FileOut.writeToFile(args[2], linBuilder.toString(), true, true);
                    linBuilder.setLength(0); // Satırı temizle
                } else {
                    linBuilder.append(""); // Öğeleri ayırmak için boşluk ekle
                }
            }
        }
        FileOut.writeToFile(args[2], "----------", true, true);


        for (String line : purchaseContent) {
            String[] satir = line.split("\t");
            String type=satir[0];
            String[] money = satir[1].split(" ");
            String choiceType=satir[2];
            int value=Integer.parseInt(satir[3]);
            gymMealMachine.purchase(line,type,choiceType,value,money,productContent,args);

        }


        gmmArray = gymMealMachine.getGmmArray();
        FileOut.writeToFile(args[2], "-----Gym Meal Machine-----", true, true);
        StringBuilder lineBuilder = new StringBuilder();
        int itemCount = 0;

        for (int i = 0; i < gmmArray.length; i++) {
            for (int j = 0; j < gmmArray[0].length; j++) {
                if (gmmArray[i][j][0] == null) {
                    lineBuilder.append("___(0, 0)___");
                } else {
                    String[] isimIcin = gmmArray[i][j][0].split("\t");
                    String productName = isimIcin[0];
                    String[] nutritions = isimIcin[2].split(" ");
                    double protein = Double.parseDouble(nutritions[0]);
                    double carb = Double.parseDouble(nutritions[1]);
                    double fat = Double.parseDouble(nutritions[2]);
                    double calorie = gymMealMachine.calculateCalorie(protein, carb, fat);
                    int calorie1 = (int) Math.round(calorie);
                    int leftovers = gymMealMachine.leftover(i, j);
                    String itemString = String.format("%s(%d, %d)___", productName, calorie1, leftovers);
                    lineBuilder.append(itemString);
                }

                itemCount++;
                // Satır sonuna ulaşıldığında veya son elemana ulaşıldığında, satırı dosyaya yaz ve satırı temizle
                if (itemCount % 4 == 0 || (i == gmmArray.length - 1 && j == gmmArray[0].length - 1)) {
                    FileOut.writeToFile(args[2], lineBuilder.toString(), true, true);
                    lineBuilder.setLength(0); // Satırı temizle
                } else {
                    lineBuilder.append(""); // Öğeleri ayırmak için boşluk ekle
                }
            }
        }
        FileOut.writeToFile(args[2], "----------", true, true);

    }
}