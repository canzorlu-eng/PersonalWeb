import java.io.*;
import java.util.*;
import java.nio.file.*;


class FileOut {

    /**
     * This method writes given content to file at given path.
     *
     * @param path    Path for the file content is going to be written.
     * @param content Content that is going to be written to file.
     * @param append  Append status, true if wanted to append to file if it exists, false if wanted to create file from zero.
     * @param newLine True if wanted to append a new line after content, false if vice versa.
     */
    public static void writeToFile(String path, String content, boolean append, boolean newLine) {
        PrintStream ps = null;
        try {
            ps = new PrintStream(new FileOutputStream(path, append));
            ps.print(content + (newLine ? "\n" : ""));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (ps != null) {
                ps.flush();
                ps.close();
            }
        }
    }
}


public class MapAnalyzer {
    private static Map<String, List<Road>> adjacencyList = new HashMap<>();

    public static void main(String[] args) {
        Locale.setDefault(Locale.US);

        String inputFile = args[0];
        String outputFile = args[1];

        List<Road> roads = new ArrayList<>();
        String startPoint = "";
        String endPoint = "";

        String[] lines = FileIn.readFile(inputFile, true, true);
        if (lines != null && lines.length > 0) {
            String[] points = lines[0].split("\t");
            startPoint = points[0];
            endPoint = points[1];

            for (int i = 1; i < lines.length; i++) {
                String[] parts = lines[i].split("\t");
                String pointA = parts[0];
                String pointB = parts[1];
                int distance = Integer.parseInt(parts[2]);
                int id = Integer.parseInt(parts[3]);
                Road road = new Road(pointA, pointB, distance, id);
                roads.add(road);
                addToAdjacencyList(pointA, road);
                addToAdjacencyList(pointB, road);
            }
        }

        List<Road> fastestRoute = findFastestRoute(startPoint, endPoint);
        List<Road> barelyConnectedMap = findBarelyConnectedMap(roads);
        List<Road> fastestRouteInBarelyConnectedMap = findFastestRouteInBarelyConnectedMap(startPoint, endPoint, barelyConnectedMap);

        int fastestRouteDistance = calculateTotalDistance(fastestRoute);
        int fastestRouteInBarelyConnectedMapDistance = calculateTotalDistance(fastestRouteInBarelyConnectedMap);
        double distanceRatio = calculateDistanceRatio(fastestRouteDistance, fastestRouteInBarelyConnectedMapDistance);
        double materialUsageRatio = calculateMaterialUsageRatio(roads, barelyConnectedMap);

        StringBuilder outputContent = new StringBuilder();
        outputContent.append("Fastest Route from ").append(startPoint).append(" to ").append(endPoint).append(" (").append(fastestRouteDistance).append(" KM):\n");
        appendRoadsToOutput(fastestRoute, outputContent);
        outputContent.append("Roads of Barely Connected Map is:\n");
        appendRoadsToOutput(barelyConnectedMap, outputContent);
        outputContent.append("Fastest Route from ").append(startPoint).append(" to ").append(endPoint).append(" on Barely Connected Map (").append(fastestRouteInBarelyConnectedMapDistance).append(" KM):\n");
        appendRoadsToOutput(fastestRouteInBarelyConnectedMap, outputContent);
        outputContent.append("Analysis:\n");
        outputContent.append("Ratio of Construction Material Usage Between Barely Connected and Original Map: ").append(String.format("%.2f", materialUsageRatio)).append("\n");
        outputContent.append("Ratio of Fastest Route Between Barely Connected and Original Map: ").append(String.format("%.2f", distanceRatio));

        FileOut.writeToFile(outputFile, outputContent.toString(), false, false);
    }

    private static void addToAdjacencyList(String point, Road road) {
        if (!adjacencyList.containsKey(point)) {
            adjacencyList.put(point, new ArrayList<>());
        }
        adjacencyList.get(point).add(road);
    }

    private static List<Road> findFastestRoute(String startPoint, String endPoint) {
        // Dijkstra's algorithm
        Map<String, Integer> distances = new HashMap<>();
        Map<String, Road> previous = new HashMap<>();
        PriorityQueue<String> queue = new PriorityQueue<>(Comparator.comparingInt(distances::get).thenComparingInt(node -> {
            Road road = previous.get(node);
            return (road != null) ? road.getId() : Integer.MAX_VALUE;
        }));        Set<String> visited = new HashSet<>();

        distances.put(startPoint, 0);
        queue.add(startPoint);

        while (!queue.isEmpty()) {
            String current = queue.poll();
            if (visited.contains(current)){
                continue;
            }
            visited.add(current);

            if (current.equals(endPoint)) {
                break;
            }

            for (Road road : adjacencyList.getOrDefault(current,Collections.emptyList())) {
                String neighbor = road.getPointA().equals(current) ? road.getPointB() : road.getPointA();
                if (visited.contains(neighbor)){
                    continue;
                }
                int newDist = distances.get(current) + road.getDistance();
                if (newDist < distances.getOrDefault(neighbor,Integer.MAX_VALUE)) {
                    distances.put(neighbor, newDist);
                    previous.put(neighbor, road);
                    queue.add(neighbor);
                }
            }
        }

        List<Road> path = new ArrayList<>();
        for (String at = endPoint; previous.containsKey(at); at = (previous.get(at).getPointA().equals(at)) ? previous.get(at).getPointB() : previous.get(at).getPointA()) {
            path.add(previous.get(at));
        }
        Collections.reverse(path);

        return path;
    }

    private static List<Road> findBarelyConnectedMap(List<Road> roads) {
        // Using Kruskal's algorithm to find the Minimum Spanning Tree
        UnionFind uf = new UnionFind();
        List<Road> barelyConnectedMap = new ArrayList<>();

        // Initialize Union-Find structure
        for (Road road : roads) {
            uf.add(road.getPointA());
            uf.add(road.getPointB());
        }

        // Sort roads by distance, and then by ID
        roads.sort(Comparator.comparingInt(Road::getDistance).thenComparingInt(Road::getId));

        // Kruskal's algorithm to find the Minimum Spanning Tree (MST)
        for (Road road : roads) {
            if (uf.union(road.getPointA(), road.getPointB())) {
                barelyConnectedMap.add(road);
            }
        }

        return barelyConnectedMap;
    }

    private static List<Road> findFastestRouteInBarelyConnectedMap(String startPoint, String endPoint, List<Road> barelyConnectedMap) {
        // Rebuild the adjacency list for the barely connected map
        adjacencyList.clear();
        for (Road road : barelyConnectedMap) {
            addToAdjacencyList(road.getPointA(), road);
            addToAdjacencyList(road.getPointB(), road);
        }
        // Find the fastest route in the barely connected map
        return findFastestRoute(startPoint, endPoint);
    }

    private static int calculateTotalDistance(List<Road> roads) {
        int totalDistance = 0;
        for (Road road : roads) {
            totalDistance += road.getDistance();
        }
        return totalDistance;
    }

    private static double calculateDistanceRatio(int originalDistance, int newDistance) {
        double ratio;
        if (originalDistance == 0) {
            ratio = 1;
        } else {
            ratio = (double) newDistance / originalDistance;
        }
        return ratio;
    }

    private static double calculateMaterialUsageRatio(List<Road> originalMap, List<Road> barelyConnectedMap) {
        int originalMaterial = calculateTotalDistance(originalMap);
        int newMaterial = calculateTotalDistance(barelyConnectedMap);
        double ratio = (double) newMaterial / originalMaterial;
        return ratio;
    }

    private static void appendRoadsToOutput(List<Road> roads, StringBuilder outputContent) {
        for (Road road : roads) {
            outputContent.append(road.getPointA()).append("\t").append(road.getPointB()).append("\t").append(road.getDistance()).append("\t").append(road.getId()).append("\n");
        }
    }
}

class UnionFind {
    private Map<String, String> parent = new HashMap<>();
    private Map<String, Integer> rank = new HashMap<>();

    public void add(String s) {
        if (!parent.containsKey(s)) {
            parent.put(s, s);
            rank.put(s, 0);
        }
    }

    public String find(String s) {
        if (!s.equals(parent.get(s))) {
            parent.put(s, find(parent.get(s)));
        }
        return parent.get(s);
    }

    public boolean union(String s1, String s2) {
        String root1 = find(s1);
        String root2 = find(s2);
        if (root1.equals(root2)) {
            return false;
        }
        int rank1 = rank.get(root1);
        int rank2 = rank.get(root2);
        if (rank1 > rank2) {
            parent.put(root2, root1);
        } else if (rank1 < rank2) {
            parent.put(root1, root2);
        } else {
            parent.put(root2, root1);
            rank.put(root1, rank1 + 1);
        }
        return true;
    }
}

class Road {
    private String pointA;
    private String pointB;
    private int distance;
    private int id;

    public Road(String pointA, String pointB, int distance, int id) {
        this.pointA = pointA;
        this.pointB = pointB;
        this.distance = distance;
        this.id = id;
    }

    public String getPointA() {
        return pointA;
    }

    public String getPointB() {
        return pointB;
    }

    public int getDistance() {
        return distance;
    }

    public int getId() {
        return id;
    }
}

class FileIn {

    /**
     * Reads the file at the given path and returns contents of it in a string array.
     *
     * @param path              Path to the file that is going to be read.
     * @param discardEmptyLines If true, discards empty lines with respect to trim; else, it takes all the lines from the file.
     * @param trim              Trim status; if true, trims (strip in Python) each line; else, it leaves each line as-is.
     * @return Contents of the file as a string array, returns null if there is not such a file or this program does not have sufficient permissions to read that file.
     */
    public static String[] readFile(String path, boolean discardEmptyLines, boolean trim) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(path));
            if (discardEmptyLines) {
                lines.removeIf(line -> line.trim().equals(""));
            }
            if (trim) {
                lines.replaceAll(String::trim);
            }
            return lines.toArray(new String[0]);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}

