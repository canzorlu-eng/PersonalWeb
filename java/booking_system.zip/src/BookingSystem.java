import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.io.*;


class IllegalArgumentException1 extends IllegalArgumentException {
    public IllegalArgumentException1(String message) {
        super(message);
    }
}

class IllegalArgumentException2 extends IllegalArgumentException {
    public IllegalArgumentException2(String message) {
        super(message);
    }
}
class IllegalArgumentException3 extends IllegalArgumentException {
    public IllegalArgumentException3(String message) {
        super(message);
    }
}


class DosyaIslemleri {
    public static void dosya(String[] args) {
        String dosyaYolu = args[1];
        try {
            // Dosyayı okumak için bir FileReader
            FileReader fr = new FileReader(dosyaYolu);
            BufferedReader br = new BufferedReader(fr);

            StringBuilder yeniIcerik = new StringBuilder();
            String satir;
            while ((satir = br.readLine()) != null) {
                yeniIcerik.append(satir).append("\n");
            }
            if (yeniIcerik.length() > 0 && yeniIcerik.charAt(yeniIcerik.length() - 1) == '\n') {
                yeniIcerik.deleteCharAt(yeniIcerik.length() - 1); // Son newline karakterini kaldırır
            }
            br.close();
            // Dosyanın üzerine yazmak için bir FileWriter
            FileWriter fw = new FileWriter(dosyaYolu);
            BufferedWriter bw = new BufferedWriter(fw);
            // Yeni içeriği dosyaya yaz
            bw.write(yeniIcerik.toString());
            // Dosyayı kapat
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
class FileIn {
    /**
     * Reads the file at the given path and returns contents of it in a string array.
     *
     * @param path              Path to the file that is going to be read.
     * @param discardEmptyLines If true, discards empty lines with respect to trim; else, it takes all the lines from the file.
     * @param trim              Trim status; if true, trims (strip in Python) each line; else, it leaves each line as-is.
     * @return Contents of the file as a string array, returns null if there is not such a file or this program does not have sufficient permissions to read that file.
     */
    public static String[] readFile(String path, boolean discardEmptyLines, boolean trim) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(path));
            if (discardEmptyLines) {
                lines.removeIf(line -> line.trim().equals(""));
            }
            if (trim) {
                lines.replaceAll(String::trim);
            }
            return lines.toArray(new String[0]);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}

class FileOut {
    /**
     * This method writes given content to file at given path.
     *
     * @param path    Path for the file content is going to be written.
     * @param content Content that is going to be written to file.
     * @param append  Append status, true if wanted to append to file if it exists, false if wanted to create file from zero.
     * @param newLine True if wanted to append a new line after content, false if vice versa.
     */
    public static void writeToFile(String path, String content, boolean append, boolean newLine) {
        PrintStream ps = null;
        try {
            ps = new PrintStream(new FileOutputStream(path, append));
            ps.print(content + (newLine ? "\n" : ""));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (ps != null) {
                ps.flush();
                ps.close();
            }
        }
    }
}

abstract class Voyage{
    protected String type;
    protected int id;
    protected String from;
    protected String toWhere;
    protected int rows;
    protected double price;
    public Voyage(String type,int id,String from,String toWhere,int rows,double price) {
        this.type=type;
        this.id=id;
        this.from=from;
        this.toWhere=toWhere;
        this.rows=rows;
        this.price=price;
    }

    public double getPrice() {
        return price;
    }
    public int getRows() {
        return rows;
    }
    public String getToWhere() {
        return toWhere;
    }
    public String getFrom() {
        return from;
    }
    public int getId() {
        return id;
    }
    public String getType() {
        return type;
    }
}


class StandardBus extends Voyage{
    protected int refundCut;
    private String[][] standardBus;
    protected double revenue;
    public StandardBus(String type,int id,String from,String toWhere,int rows,double price,int refundCut,double revenue) {
        super(type,id,from,toWhere,rows,price);
        this.refundCut=refundCut;
        this.standardBus=new String[rows][4];
        this.revenue=revenue;
    }

    public int getRefundCut() {
        return refundCut;
    }

    public double getRevenue() {
        return revenue;
    }

    public void setRevenue(double sells) {
        this.revenue += sells;
    }
    public String[][] getStandardBus() {
        return standardBus;
    }

    public void setStandardBus(String[][] standardBus) {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < 4; j++) {
                standardBus[i][j]="*";
            }
        }
    }
}
class PremiumBus extends Voyage{
    protected double premiumFee;
    protected double revenue;
    protected int refundCut;
    private String[][] premiumBus;
    public PremiumBus(String type,int id,String from,String toWhere,int rows,double price,int refundCut,double premiumFee,double revenue) {
        super(type,id,from,toWhere,rows,price);
        this.refundCut=refundCut;
        this.premiumFee=premiumFee;
        this.premiumBus=new String[rows][3];
        this.revenue=revenue;
    }

    public int getRefundCut() {
        return refundCut;
    }

    public double getPremiumFee() {
        return premiumFee;
    }

    public double getRevenue() {
        return revenue;
    }

    public void setRevenue(double sells) {
        this.revenue += sells;
    }

    public void setPremiumBus(String[][] premiumBus) {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < 3; j++) {
                premiumBus[i][j]="*";
            }
        }
    }

    public String[][] getPremiumBus() {
        return premiumBus;
    }
}
class Minibus extends Voyage{
    private String[][] miniBus;
    protected double revenue;
    public Minibus(String type,int id,String from,String toWhere,int rows,double price,double revenue) {
        super(type,id,from,toWhere,rows,price);
        this.miniBus=new String[rows][2];
        this.revenue=revenue;
    }

    public double getRevenue() {
        return revenue;
    }

    public void setRevenue(double sells) {
        this.revenue += sells;
    }

    public void setMiniBus(String[][] miniBus) {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < 2; j++) {
                miniBus[i][j]="*";
            }
        }
    }
    public String[][] getMiniBus() {
        return miniBus;
    }
}



public class BookingSystem{
    private static Map<Integer, Voyage> voyages = new HashMap<>();
    public static void main(String[] args) {


        String[] input = FileIn.readFile(args[0], true, true);
        FileOut.writeToFile(args[1], "", false, false);


        // Process each command from the input
        for (String line : input) {
            processCommand(line,args);
        }
        DosyaIslemleri.dosya(args);

    }
    private static void processCommand(String line,String[] args) {


        // Split the command into components
        String[] parts = line.split("\t");
        // Identify the command type
        String command = parts[0];
        // Execute the corresponding action based on the command type


        switch (command) {
            case "INIT_VOYAGE":
                String f = String.format("COMMAND: %s", line);
                FileOut.writeToFile(args[1], f, true, true);
                try {
                    String type = parts[1];
                    int id = Integer.parseInt(parts[2]);

                    // Check if id already exists in voyages
                    if (voyages.containsKey(id)) {
                        String error = String.format("ERROR: There is already a voyage with ID of %d!", id);
                        FileOut.writeToFile(args[1], "ERROR: " + error, true, true);
                        break; // exit the case without processing further
                    }

                    String from = parts[3];
                    String toWhere = parts[4];
                    int rows = Integer.parseInt(parts[5]);
                    double price = Double.parseDouble(parts[6]);

                    // Check for negative values
                    if (id < 0 || rows < 0 || price < 0) {
                        if (id < 0) {
                            String error = String.format("%d is not a positive integer, ID of a voyage must be a positive integer!", id);
                            throw new IllegalArgumentException(error);
                        } else if (rows < 0) {
                            String error = String.format("%d is not a positive integer, number of seat rows of a voyage must be a positive integer!", rows);
                            throw new IllegalArgumentException(error);
                        } else {
                            String error = String.format("%d is not a positive integer, price must be a positive number!", (int) price);
                            throw new IllegalArgumentException(error);
                        }
                    }

                    double revenue = 0;

                    if (type.equals("Minibus")) {
                        Minibus minibusVoyage = new Minibus(type, id, from, toWhere, rows, price, revenue);
                        minibusVoyage.setMiniBus(minibusVoyage.getMiniBus());
                        voyages.put(id, minibusVoyage);

                        String formatted = String.format("Voyage %s was initialized as a minibus (2) voyage from %s to %s with %.2f TL" +
                                " priced %d regular seats. Note that minibus tickets are not refundable.", id, from, toWhere, price, (rows * 2));
                        FileOut.writeToFile(args[1], formatted, true, true);
                    } else if (type.equals("Standard")) {
                        int refundCut = Integer.parseInt(parts[7]);

                        // Check for negative refund cut
                        if (refundCut < 0) {
                            String error = String.format("%d is not an integer that is in range of [0, 100], refund cut must be an integer that is in range of [0, 100]!", refundCut);
                            throw new IllegalArgumentException(error);
                        }

                        StandardBus standardVoyage = new StandardBus(type, id, from, toWhere, rows, price, refundCut, revenue);
                        standardVoyage.setStandardBus(standardVoyage.getStandardBus());
                        voyages.put(id, standardVoyage);

                        String formatted = String.format("Voyage %s was initialized as a standard (2+2) voyage from " +
                                "%s to %s with %.2f TL priced %d regular seats. " +
                                "Note that refunds will be %d%% less than the paid amount.", id, from, toWhere, price, (rows * 4), refundCut);
                        FileOut.writeToFile(args[1], formatted, true, true);
                    } else if (type.equals("Premium")) {
                        int refundCut = Integer.parseInt(parts[7]);
                        double premiumFee = Double.parseDouble(parts[8]);

                        // Check for negative refund cut and premium fee
                        if (premiumFee < 0) {
                            String error = String.format("%d is not a non-negative integer, premium fee must be a non-negative integer!", (int) premiumFee);
                            throw new IllegalArgumentException(error);
                        } else if (refundCut < 0) {
                            String error = String.format("%d is not an integer that is in range of [0, 100], refund cut must be an integer that is in range of [0, 100]!", refundCut);
                            throw new IllegalArgumentException(error);
                        }

                        PremiumBus premiumVoyage = new PremiumBus(type, id, from, toWhere, rows, price, refundCut, premiumFee, revenue);
                        premiumVoyage.setPremiumBus(premiumVoyage.getPremiumBus());
                        voyages.put(id, premiumVoyage);

                        String formatted = String.format("Voyage %s was initialized as a premium (1+2) " +
                                "voyage from %s to %s with %.2f TL priced %d regular seats and %.2f TL priced 12 premium seats. " +
                                "Note that refunds will be %d%% less than the paid amount.", id, from, toWhere, price, (rows * 3), premiumFee, refundCut);
                        FileOut.writeToFile(args[1], formatted, true, true);
                    } else {
                        FileOut.writeToFile(args[1], "ERROR: Erroneous usage of \"INIT_VOYAGE\" command!", true, true);
                    }
                } catch (IllegalArgumentException e) {
                    FileOut.writeToFile(args[1], "ERROR: " + e.getMessage(), true, true);
                }
                break;


            case "SELL_TICKET":
                try {
                    double satis = 0;
                    String ff = String.format("COMMAND: %s", line);
                    FileOut.writeToFile(args[1], ff, true, true);

                    if (parts.length != 3) {
                        FileOut.writeToFile(args[1], "ERROR: Erroneous usage of \"SELL_TICKET\" command!", true, true);
                    } else {
                        int sellId = Integer.parseInt(parts[1]);
                        boolean voyageExists = voyages.values().stream().anyMatch(v -> v.getId() == sellId);

                        if (!voyageExists) {
                            String error = String.format("ERROR: There is no voyage with ID of %d!", sellId);
                            FileOut.writeToFile(args[1], error, true, true);
                        } else {
                            Voyage voyage = voyages.values().stream().filter(v -> v.getId() == sellId).findFirst().orElse(null);

                            if (voyage != null) {
                                String busType = voyage.getType();
                                int rows = voyage.getRows();
                                int seatsPerRow;

                                // Set the seats per row based on bus type
                                if (busType.equals("Standard")) {
                                    seatsPerRow = 4;
                                } else if (busType.equals("Premium")) {
                                    seatsPerRow = 3;
                                } else if (busType.equals("Minibus")) {
                                    seatsPerRow = 2;
                                } else {
                                    break;
                                }

                                int maxSeats = rows * seatsPerRow;

                                if (parts[2].contains("_")) {
                                    String[] seatNumbers = parts[2].split("_");
                                    boolean validSeats = true;

                                    for (String sNumber : seatNumbers) {
                                        int seatNumber = Integer.parseInt(sNumber);

                                        if (seatNumber < 1) {
                                            validSeats = false;
                                            String fs = String.format("ERROR: %d is not a positive integer, seat number must be a positive integer!", seatNumber);
                                            FileOut.writeToFile(args[1], fs, true, true);
                                            break;
                                        } else if (seatNumber > maxSeats) {
                                            validSeats = false;
                                            FileOut.writeToFile(args[1], "ERROR: There is no such a seat!", true, true);
                                            break;
                                        }
                                    }
                                    if (validSeats) {
                                        for (String sNumber : seatNumbers) {
                                            int seatNumber = Integer.parseInt(sNumber);

                                            switch (busType) {
                                                case "Standard": {
                                                    StandardBus sb = (StandardBus) voyage;
                                                    int row = (seatNumber - 1) / 4;
                                                    int column = (seatNumber - 1) % 4;
                                                    if (sb.getStandardBus()[row][column].equals("X")) {
                                                        validSeats = false;
                                                        throw new IllegalArgumentException1("ERROR: One or more seats already sold!");
                                                    }
                                                    break;
                                                }
                                                case "Premium": {
                                                    PremiumBus pb = (PremiumBus) voyage;
                                                    String[][] pbArr = pb.getPremiumBus();

                                                    if (seatNumber % 3 == 0) {
                                                        if (pbArr[seatNumber / 3 - 1][2].equals("X")) {
                                                            validSeats = false;
                                                            throw new IllegalArgumentException1("ERROR: One or more seats already sold!");
                                                        }
                                                    } else {
                                                        if (pbArr[seatNumber / 3][seatNumber % 3 - 1].equals("X")) {
                                                            validSeats = false;
                                                            throw new IllegalArgumentException1("ERROR: One or more seats already sold!");
                                                        }
                                                    }

                                                    break;
                                                }
                                                case "Minibus": {
                                                    Minibus mb = (Minibus) voyage;
                                                    int row = (seatNumber - 1) / 2;
                                                    int column = (seatNumber - 1) % 2;
                                                    if (mb.getMiniBus()[row][column].equals("X")) {
                                                        validSeats = false;
                                                        throw new IllegalArgumentException1("ERROR: One or more seats already sold!");
                                                    }
                                                    break;
                                                }
                                            }
                                        }

                                    }


                                    if (validSeats) {
                                        for (String sNumber : seatNumbers) {
                                            int seatNumber = Integer.parseInt(sNumber);
                                            // Logic to mark the seat as sold
                                            switch (busType) {
                                                case "Standard": {
                                                    StandardBus sb = (StandardBus) voyage;
                                                    int row = (seatNumber - 1) / 4;
                                                    int column = (seatNumber - 1) % 4;
                                                    if (sb.getStandardBus()[row][column].equals("X")) {
                                                        throw new IllegalArgumentException1("ERROR: One or more seats already sold!");
                                                    }
                                                    sb.getStandardBus()[row][column] = "X";
                                                    sb.setRevenue(sb.getPrice());
                                                    break;
                                                }
                                                case "Premium": {
                                                    PremiumBus pb = (PremiumBus) voyage;
                                                    String[][] pbArr = pb.getPremiumBus();

                                                    if (seatNumber % 3 == 0) {
                                                        if (pbArr[seatNumber / 3 - 1][2].equals("X")) {
                                                            throw new IllegalArgumentException1("ERROR: One or more seats already sold!");
                                                        }
                                                        pbArr[seatNumber / 3 - 1][2] = "X";
                                                        pb.setRevenue(pb.getPrice());
                                                        satis += pb.getPrice();
                                                    } else {
                                                        if (pbArr[seatNumber / 3][seatNumber % 3 - 1].equals("X")) {
                                                            throw new IllegalArgumentException1("ERROR: One or more seats already sold!");
                                                        }
                                                        pbArr[seatNumber / 3][seatNumber % 3 - 1] = "X";
                                                        if (seatNumber % 3 - 1 == 0) {
                                                            if (pb.getPremiumFee() == 0) {
                                                                pb.setRevenue(pb.getPrice());
                                                                satis += pb.getPrice();
                                                            } else {
                                                                double a = pb.getPrice() + (pb.getPrice() * pb.getPremiumFee() / 100);
                                                                pb.setRevenue(a);
                                                                satis += a;
                                                            }
                                                        } else {
                                                            pb.setRevenue(pb.getPrice());
                                                            satis += pb.getPrice();
                                                        }
                                                    }

                                                    break;
                                                }
                                                case "Minibus": {
                                                    Minibus mb = (Minibus) voyage;
                                                    int row = (seatNumber - 1) / 2;
                                                    int column = (seatNumber - 1) % 2;
                                                    if (mb.getMiniBus()[row][column].equals("X")) {
                                                        throw new IllegalArgumentException1("ERROR: One or more seats already sold!");
                                                    }
                                                    mb.getMiniBus()[row][column] = "X";
                                                    mb.setRevenue(mb.getPrice());
                                                    break;
                                                }
                                            }
                                        }
                                        if (!(busType.equals("Premium"))) {

                                            String seatNumbersString = String.join("-", seatNumbers);
                                            String successMessage = String.format("Seat %s of Voyage %d from %s to %s was successfully sold for %.2f TL.",
                                                    seatNumbersString, sellId, voyage.getFrom(), voyage.getToWhere(), (voyage.getPrice() * seatNumbers.length));
                                            FileOut.writeToFile(args[1], successMessage, true, true);
                                        } else {
                                            String seatNumbersString = String.join("-", seatNumbers);
                                            String successMessage = String.format("Seat %s of Voyage %d from %s to %s was successfully sold for %.2f TL.",
                                                    seatNumbersString, sellId, voyage.getFrom(), voyage.getToWhere(), satis);
                                            FileOut.writeToFile(args[1], successMessage, true, true);
                                        }
                                    }
                                } else {
                                    int seatNumber = Integer.parseInt(parts[2]);
                                    if (seatNumber < 0) {

                                        String fs = String.format("ERROR: %d is not a positive integer, seat number must be a positive integer!", seatNumber);
                                        FileOut.writeToFile(args[1], fs, true, true);
                                        break;
                                    } else if (seatNumber > maxSeats) {
                                        FileOut.writeToFile(args[1], "ERROR: There is no such a seat!", true, true);
                                        break;
                                    } else {
                                        // Logic to mark the seat as sold
                                        switch (busType) {
                                            case "Standard": {
                                                StandardBus sb = (StandardBus) voyage;
                                                int row = (seatNumber - 1) / 4;
                                                int column = (seatNumber - 1) % 4;
                                                if (sb.getStandardBus()[row][column].equals("X")) {
                                                    throw new IllegalArgumentException2("ERROR: Seat already sold!");
                                                }
                                                sb.getStandardBus()[row][column] = "X";
                                                sb.setRevenue(sb.getPrice());
                                                break;
                                            }
                                            case "Premium": {
                                                PremiumBus pb = (PremiumBus) voyage;
                                                String[][] pbArr = pb.getPremiumBus();
                                                if (seatNumber % 3 == 0) {
                                                    if (pbArr[seatNumber / 3 - 1][2].equals("X")) {
                                                        throw new IllegalArgumentException2("ERROR: Seat already sold!");
                                                    }
                                                    pbArr[seatNumber / 3 - 1][2] = "X";
                                                    pb.setRevenue(pb.getPrice());
                                                    satis += pb.getPrice();
                                                } else {
                                                    if (pbArr[seatNumber / 3][seatNumber % 3 - 1].equals("X")) {
                                                        throw new IllegalArgumentException2("ERROR: Seat already sold!");
                                                    }
                                                    pbArr[seatNumber / 3][seatNumber % 3 - 1] = "X";
                                                    if (seatNumber % 3 - 1 == 0) {
                                                        if (pb.getPremiumFee() == 0) {
                                                            pb.setRevenue(pb.getPrice());
                                                            satis += pb.getPrice();
                                                        } else {
                                                            double a = pb.getPrice() + (pb.getPrice() * pb.getPremiumFee() / 100);
                                                            pb.setRevenue(a);
                                                            satis += a;
                                                        }
                                                    } else {
                                                        pb.setRevenue(pb.getPrice());
                                                        satis += pb.getPrice();
                                                    }
                                                }

                                                String successMessage = String.format("Seat %d of Voyage %d from %s to %s was successfully sold for %.2f TL.",
                                                        seatNumber, sellId, voyage.getFrom(), voyage.getToWhere(), satis);
                                                FileOut.writeToFile(args[1], successMessage, true, true);

                                                break;
                                            }
                                            case "Minibus": {
                                                Minibus mb = (Minibus) voyage;
                                                int row = (seatNumber - 1) / 2;
                                                int column = (seatNumber - 1) % 2;
                                                if (mb.getMiniBus()[row][column].equals("X")) {
                                                    throw new IllegalArgumentException2("ERROR: Seat already sold!");
                                                }
                                                mb.getMiniBus()[row][column] = "X";
                                                mb.setRevenue(mb.getPrice());
                                                break;
                                            }
                                        }

                                        if (!(busType.equals("Premium"))) {
                                            String successMessage = String.format("Seat %d of Voyage %d from %s to %s was successfully sold for %.2f TL.",
                                                    seatNumber, sellId, voyage.getFrom(), voyage.getToWhere(), voyage.getPrice());
                                            FileOut.writeToFile(args[1], successMessage, true, true);
                                        }
                                    }
                                }
                            }
                        }
                    }

                } catch (IllegalArgumentException1 e) {
                    FileOut.writeToFile(args[1], e.getMessage(), true, true);
                } catch (IllegalArgumentException2 e) {
                    FileOut.writeToFile(args[1], e.getMessage(), true, true);
                }
                break;


            case "REFUND_TICKET":
                try {
                    String fff = String.format("COMMAND: %s", line);
                    FileOut.writeToFile(args[1], fff, true, true);

                    if (parts.length != 3) {
                        FileOut.writeToFile(args[1], "ERROR: Erroneous usage of \"REFUND_TICKET\" command!", true, true);
                    } else {
                        int refundId = Integer.parseInt(parts[1]);
                        Voyage voyage = voyages.values().stream().filter(v -> v.getId() == refundId).findFirst().orElse(null);

                        if (voyage == null) {
                            String error = String.format("ERROR: There is no voyage with ID of %d!", refundId);
                            FileOut.writeToFile(args[1], error, true, true);
                        } else {
                            String busType = voyage.getType();
                            int rows = voyage.getRows();
                            int seatsPerRow;

                            // Set seats per row based on bus type
                            if (busType.equals("Standard")) {
                                seatsPerRow = 4;
                            } else if (busType.equals("Premium")) {
                                seatsPerRow = 3;
                            } else if (busType.equals("Minibus")) {
                                seatsPerRow = 2;
                            } else {
                                break;
                            }

                            int maxSeats = rows * seatsPerRow;

                            if (busType.equals("Minibus")) {
                                FileOut.writeToFile(args[1], "ERROR: Minibus tickets are not refundable!", true, true);
                                break;
                            } else if (parts[2].contains("_")) {
                                String[] seatNumbers = parts[2].split("_");
                                boolean validSeats = true;

                                for (String sNumber : seatNumbers) {
                                    int seatNumber = Integer.parseInt(sNumber);

                                    if (seatNumber < 1){
                                        String s=String.format("ERROR: %d is not a positive integer, seat number must be a positive integer!",seatNumber);
                                        FileOut.writeToFile(args[1], s, true, true);
                                        validSeats=false;
                                    }
                                    else if (seatNumber > maxSeats) {
                                        validSeats = false;
                                        FileOut.writeToFile(args[1], "ERROR: There is no such a seat!", true, true);
                                        break;
                                    }
                                }

                                if (validSeats){
                                    for (String sNumber : seatNumbers) {
                                        int seatNumber = Integer.parseInt(sNumber);
                                        if (busType.equals("Standard")) {
                                            StandardBus sb = (StandardBus) voyage;
                                            int row = (seatNumber - 1) / 4;
                                            int column = (seatNumber - 1) % 4;
                                            if (sb.getStandardBus()[row][column].equals("*")){
                                                validSeats=false;
                                                throw new IllegalArgumentException3("ERROR: One or more seats are already empty!");

                                            }
                                        } else {
                                            PremiumBus pb = (PremiumBus) voyage;
                                            String[][] pbArr = pb.getPremiumBus();
                                            if (seatNumber % 3 == 0) {
                                                if (pbArr[seatNumber / 3 - 1][2].equals("*")){
                                                    validSeats=false;
                                                    throw new IllegalArgumentException3("ERROR: One or more seats are already empty!");

                                                }
                                            } else {
                                                if (pbArr[seatNumber / 3][seatNumber % 3 - 1].equals("*")){
                                                    validSeats=false;
                                                    throw new IllegalArgumentException3("ERROR: One or more seats are already empty!");

                                                }
                                            }
                                        }
                                    }
                                }

                                if (validSeats) {
                                    double totalRefundAmount = 0;
                                    double refundCutAmount = 0;

                                    for (String sNumber : seatNumbers) {
                                        int seatNumber = Integer.parseInt(sNumber);

                                        if (busType.equals("Standard")) {
                                            StandardBus sb = (StandardBus) voyage;
                                            int row = (seatNumber - 1) / 4;
                                            int column = (seatNumber - 1) % 4;
                                            sb.getStandardBus()[row][column] = "*";
                                            refundCutAmount = sb.getPrice() * sb.getRefundCut() / 100;
                                            totalRefundAmount += sb.getPrice() - refundCutAmount;
                                            sb.setRevenue(-1 * (sb.getPrice() - refundCutAmount));
                                        } else {
                                            PremiumBus pb = (PremiumBus) voyage;
                                            String[][] pbArr = pb.getPremiumBus();
                                            if (seatNumber % 3 == 0) {
                                                pbArr[seatNumber / 3 - 1][2] = "*";
                                                refundCutAmount = pb.getPrice() * pb.getRefundCut() / 100;

                                                double x = pb.getPrice() - refundCutAmount;
                                                totalRefundAmount +=x;
                                                pb.setRevenue(-1 * x);
                                            } else {
                                                pbArr[seatNumber / 3][seatNumber % 3 - 1] = "*";
                                                if (seatNumber % 3 - 1 == 0) {
                                                    if (pb.getPremiumFee() == 0) {
                                                        refundCutAmount = pb.getPrice() * pb.getRefundCut() / 100;
                                                        double x = pb.getPrice() - refundCutAmount;
                                                        totalRefundAmount +=x;
                                                        pb.setRevenue(-1 * x);
                                                    } else {
                                                        double a = pb.getPrice() + (pb.getPrice() * pb.getPremiumFee() / 100);
                                                        refundCutAmount = a * pb.getRefundCut() / 100;
                                                        double x = a - refundCutAmount;
                                                        totalRefundAmount +=x;
                                                        pb.setRevenue(-1 * x);
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    String seatNumbersString = String.join("-", seatNumbers);
                                    String successMessage = String.format("Seat %s of the Voyage %d from %s to %s were successfully refunded for %.2f TL.",
                                            seatNumbersString, refundId, voyage.getFrom(), voyage.getToWhere(), totalRefundAmount);
                                    FileOut.writeToFile(args[1], successMessage, true, true);
                                }
                            } else {
                                int seatNumber = Integer.parseInt(parts[2]);
                                if (seatNumber < 1){
                                    String s=String.format("ERROR: %d is not a positive integer, seat number must be a positive integer!",seatNumber);
                                    FileOut.writeToFile(args[1], s, true, true);
                                }
                                else if (seatNumber > maxSeats) {
                                    FileOut.writeToFile(args[1], "ERROR: There is no such a seat!", true, true);
                                }
                                 else {
                                    double refundCutAmount;
                                    double refundAmount;

                                    if (busType.equals("Standard")) {
                                        StandardBus sb = (StandardBus) voyage;
                                        int row = (seatNumber - 1) / 4;
                                        int column = (seatNumber - 1) % 4;
                                        sb.getStandardBus()[row][column] = "*";
                                        refundCutAmount = sb.getPrice() * sb.getRefundCut() / 100;
                                        refundAmount = sb.getPrice() - refundCutAmount;
                                        sb.setRevenue(-1 * refundAmount);

                                        String successMessage = String.format("Seat %d of the Voyage %d from %s to %s was successfully refunded for %.2f TL.", seatNumber, refundId, voyage.getFrom(), voyage.getToWhere(), refundAmount);
                                        FileOut.writeToFile(args[1], successMessage, true, true);
                                    } else {
                                        PremiumBus pb = (PremiumBus) voyage;
                                        String[][] pbArr = pb.getPremiumBus();
                                        if (seatNumber % 3 == 0) {
                                            pbArr[seatNumber / 3 - 1][2] = "*";
                                            refundCutAmount = pb.getPrice() * pb.getRefundCut() / 100;
                                            double x = pb.getPrice() - refundCutAmount;
                                            pb.setRevenue(-1 * x);
                                            String as = String.format("Seat %d of the Voyage %d from %s to %s was successfully refunded for %.2f TL.", seatNumber, refundId, voyage.getFrom(), voyage.getToWhere(), (pb.getPrice() - refundCutAmount));
                                            FileOut.writeToFile(args[1], as, true, true);
                                        } else {
                                            pbArr[seatNumber / 3][seatNumber % 3 - 1] = "*";
                                            if (seatNumber % 3 - 1 == 0) {
                                                if (pb.getPremiumFee() == 0) {
                                                    refundCutAmount = pb.getPrice() * pb.getRefundCut() / 100;
                                                    double x = pb.getPrice() - refundCutAmount;
                                                    pb.setRevenue(-1 * x);
                                                    String as = String.format("Seat %d of the Voyage %d from %s to %s was successfully refunded for %.2f TL.", seatNumber, refundId, voyage.getFrom(), voyage.getToWhere(), (pb.getPrice() - refundCutAmount));
                                                    FileOut.writeToFile(args[1], as, true, true);
                                                } else {
                                                    double a = pb.getPrice() + (pb.getPrice() * pb.getPremiumFee() / 100);
                                                    refundCutAmount = a * pb.getRefundCut() / 100;
                                                    double x = a - refundCutAmount;
                                                    pb.setRevenue(-1 * x);
                                                    String as = String.format("Seat %d of the Voyage %d from %s to %s was successfully refunded for %.2f TL.", seatNumber, refundId, voyage.getFrom(), voyage.getToWhere(), (a - refundCutAmount));
                                                    FileOut.writeToFile(args[1], as, true, true);
                                                }
                                            }else {
                                                refundCutAmount = pb.getPrice() * pb.getRefundCut() / 100;
                                                double x = pb.getPrice() - refundCutAmount;
                                                pb.setRevenue(-1 * x);
                                                String as = String.format("Seat %d of the Voyage %d from %s to %s was successfully refunded for %.2f TL.", seatNumber, refundId, voyage.getFrom(), voyage.getToWhere(), (pb.getPrice() - refundCutAmount));
                                                FileOut.writeToFile(args[1], as, true, true);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }catch (IllegalArgumentException3 e){
                    FileOut.writeToFile(args[1], e.getMessage(), true, true);
                }

                break;

            case "PRINT_VOYAGE":
                String f6=String.format("COMMAND: %s",line);
                FileOut.writeToFile(args[1],f6, true, true);

                if (parts.length!=2){
                    FileOut.writeToFile(args[1],"ERROR: Erroneous usage of \"PRINT_VOYAGE\" command!", true, true);
                }
                else {
                    int wantedId=Integer.parseInt(parts[1]);
                    boolean voyageExists = voyages.values().stream().anyMatch(v -> v.getId() == wantedId);
                    if (wantedId<1) {
                        String f1 = String.format("ERROR: %d is not a positive integer, ID of a voyage must be a positive integer!", wantedId);
                        FileOut.writeToFile(args[1], f1, true, true);
                    }
                    else if (!voyageExists) {
                        String error = String.format("ERROR: There is no voyage with ID of %d!", wantedId);
                        FileOut.writeToFile(args[1], error, true, true);
                    }
                    else {
                        for (Voyage v : voyages.values()) {
                            if (v.getId()==wantedId){
                                String f1 = String.format("Voyage %s", v.getId());
                                FileOut.writeToFile(args[1], f1, true, true);
                                String f2 = String.format("%s-%s", v.getFrom(), v.getToWhere());
                                FileOut.writeToFile(args[1], f2, true, true);

                                if (v.getType().equals("Standard")){
                                    StandardBus sb=(StandardBus) v;
                                    String[][] sbArr = sb.getStandardBus();
                                    for (int i = 0; i < sb.getRows(); i++) {
                                        for (int j = 0; j < 4; j++) {
                                            if (j==2){
                                                FileOut.writeToFile(args[1],"| ", true, false);
                                                FileOut.writeToFile(args[1], sbArr[i][j], true, false);
                                                FileOut.writeToFile(args[1], " ", true, false);
                                            }
                                            else {
                                                FileOut.writeToFile(args[1], sbArr[i][j], true, false);
                                                FileOut.writeToFile(args[1], " ", true, false);
                                            }
                                        }
                                        FileOut.writeToFile(args[1],"", true, true);
                                    }
                                    String revenueForPrint=String.format("Revenue: %.2f",sb.getRevenue());
                                    FileOut.writeToFile(args[1], revenueForPrint, true, true);
                                } else if (v.getType().equals("Premium")) {
                                    PremiumBus pb=(PremiumBus) v;
                                    String[][] pbArr = pb.getPremiumBus();
                                    for (int i = 0; i < pb.getRows(); i++) {
                                        for (int j = 0; j < 3; j++) {
                                            if (j==1){
                                                FileOut.writeToFile(args[1],"| ", true, false);
                                                FileOut.writeToFile(args[1], pbArr[i][j], true, false);
                                                FileOut.writeToFile(args[1], " ", true, false);
                                            }
                                            else {
                                                FileOut.writeToFile(args[1], pbArr[i][j], true, false);
                                                FileOut.writeToFile(args[1], " ", true, false);
                                            }
                                        }
                                        FileOut.writeToFile(args[1],"", true, true);
                                    }
                                    String revenueForPrint=String.format("Revenue: %.2f",pb.getRevenue());
                                    FileOut.writeToFile(args[1], revenueForPrint, true, true);
                                }
                                else if (v.getType().equals("Minibus")) {
                                    Minibus mb=(Minibus) v;
                                    String[][] mbArr = mb.getMiniBus();
                                    for (int i = 0; i < mb.getRows(); i++) {
                                        for (int j = 0; j < 2; j++) {
                                            FileOut.writeToFile(args[1], mbArr[i][j], true, false);
                                            FileOut.writeToFile(args[1], " ", true, false);
                                        }
                                        FileOut.writeToFile(args[1],"", true, true);
                                    }
                                    String revenueForPrint=String.format("Revenue: %.2f",mb.getRevenue());
                                    FileOut.writeToFile(args[1], revenueForPrint, true, true);
                                }
                            }
                        }
                    }
                }

                break;

            case "CANCEL_VOYAGE":
                String fg=String.format("COMMAND: %s",command);
                FileOut.writeToFile(args[1],fg, true, true);
                if (parts.length!=2){
                    FileOut.writeToFile(args[1],"ERROR: Erroneous usage of \"CANCEL_VOYAGE\" command!", true, true);
                }
                else {
                    int cancelledId=Integer.parseInt(parts[1]);
                    boolean voyageExists = voyages.values().stream().anyMatch(v -> v.getId() == cancelledId);
                    if (cancelledId<1){
                        String f1 = String.format("ERROR: %d is not a positive integer, ID of a voyage must be a positive integer!", cancelledId);
                        FileOut.writeToFile(args[1], f1, true, true);
                    }
                    else if (!voyageExists) {
                        String error = String.format("ERROR: There is no voyage with ID of %d!", cancelledId);
                        FileOut.writeToFile(args[1], error, true, true);
                    }

                    else {
                        String fg1=String.format("Voyage %s was successfully cancelled!",parts[1]);
                        FileOut.writeToFile(args[1],fg1, true, true);
                        FileOut.writeToFile(args[1], "Voyage details can be found below:", true, true);


                        for (Voyage v : voyages.values()) {
                            if (v.getId()==cancelledId){
                                String f1 = String.format("Voyage %s", v.getId());
                                FileOut.writeToFile(args[1], f1, true, true);
                                String f2 = String.format("%s-%s", v.getFrom(), v.getToWhere());
                                FileOut.writeToFile(args[1], f2, true, true);

                                if (v.getType().equals("Standard")){
                                    StandardBus sb=(StandardBus) v;
                                    String[][] sbArr = sb.getStandardBus();
                                    int satilanBiletler=0;
                                    for (int i = 0; i < sb.getRows(); i++) {
                                        for (int j = 0; j < 4; j++) {
                                            if (j==2){
                                                FileOut.writeToFile(args[1],"| ", true, false);
                                                FileOut.writeToFile(args[1], sbArr[i][j], true, false);
                                                FileOut.writeToFile(args[1], " ", true, false);
                                                if (sbArr[i][j].equals("X"))
                                                    satilanBiletler++;
                                            }
                                            else {
                                                FileOut.writeToFile(args[1], sbArr[i][j], true, false);
                                                FileOut.writeToFile(args[1], " ", true, false);
                                                if (sbArr[i][j].equals("X"))
                                                    satilanBiletler++;
                                            }
                                        }
                                        FileOut.writeToFile(args[1],"", true, true);
                                    }
                                    String revenueForPrint=String.format("Revenue: %.2f",sb.getRevenue()-(satilanBiletler*sb.getPrice()));
                                    FileOut.writeToFile(args[1], revenueForPrint, true, true);
                                } else if (v.getType().equals("Premium")) {
                                    PremiumBus pb=(PremiumBus) v;
                                    String[][] pbArr = pb.getPremiumBus();
                                    int satilanBiletler=0;
                                    int satilanPremiumBiletler=0;
                                    for (int i = 0; i < pb.getRows(); i++) {
                                        for (int j = 0; j < 3; j++) {
                                            if (j==1){
                                                FileOut.writeToFile(args[1],"| ", true, false);
                                                FileOut.writeToFile(args[1], pbArr[i][j], true, false);
                                                FileOut.writeToFile(args[1], " ", true, false);
                                                if (pbArr[i][j].equals("X"))
                                                    satilanBiletler++;
                                            }
                                            else {
                                                FileOut.writeToFile(args[1], pbArr[i][j], true, false);
                                                FileOut.writeToFile(args[1], " ", true, false);
                                                if (pbArr[i][j].equals("X")) {
                                                    if (j==2)
                                                        satilanBiletler++;
                                                    else
                                                        satilanPremiumBiletler++;
                                                }
                                            }
                                        }
                                        FileOut.writeToFile(args[1],"", true, true);
                                    }
                                    String revenueForPrint=String.format("Revenue: %.2f",pb.getRevenue()-(satilanBiletler* pb.getPrice() + (satilanPremiumBiletler*(pb.getPrice()+(pb.getPrice()*pb.getPremiumFee()/100)))));
                                    FileOut.writeToFile(args[1], revenueForPrint, true, true);
                                }
                                else if (v.getType().equals("Minibus")) {
                                    Minibus mb=(Minibus) v;
                                    String[][] mbArr = mb.getMiniBus();
                                    int satilanBilet=0;
                                    for (int i = 0; i < mb.getRows(); i++) {
                                        for (int j = 0; j < 2; j++) {
                                            FileOut.writeToFile(args[1], mbArr[i][j], true, false);
                                            FileOut.writeToFile(args[1], " ", true, false);
                                            if (mbArr[i][j].equals("X"))
                                                satilanBilet++;
                                        }
                                        FileOut.writeToFile(args[1],"", true, true);
                                    }
                                    String revenueForPrint=String.format("Revenue: %.2f",mb.getRevenue()-(satilanBilet*mb.getPrice()));
                                    FileOut.writeToFile(args[1], revenueForPrint, true, true);
                                }
                            }
                        }
                        Iterator<Map.Entry<Integer, Voyage>> iterator = voyages.entrySet().iterator();
                        while (iterator.hasNext()) {
                            Map.Entry<Integer, Voyage> entry = iterator.next();
                            if (entry.getKey() == cancelledId) {
                                iterator.remove(); // Belirtilen ID'ye sahip girişi kaldır
                            }
                        }
                    }
                    }
                break;


            case "Z_REPORT":
                String ffff=String.format("COMMAND: %s",line);
                FileOut.writeToFile(args[1],ffff, true, true);
                if (parts.length!=1){
                    FileOut.writeToFile(args[1], "ERROR: Erroneous usage of \"Z_REPORT\" command!", true, true);

                }
                else {
                    FileOut.writeToFile(args[1], "Z Report:", true, true);
                    FileOut.writeToFile(args[1], "----------------", true, true);
                    List<Voyage> sortedVoyages = new ArrayList<>(voyages.values());
                    sortedVoyages.sort(Comparator.comparing(Voyage::getId));
                    if (sortedVoyages.isEmpty())
                        FileOut.writeToFile(args[1], "No Voyages Available!\n----------------", true, true);
                    for (Voyage v : sortedVoyages) {
                        String f1 = String.format("Voyage %s", v.getId());
                        FileOut.writeToFile(args[1], f1, true, true);
                        String f2 = String.format("%s-%s", v.getFrom(), v.getToWhere());
                        FileOut.writeToFile(args[1], f2, true, true);

                        if (v.getType().equals("Standard")){
                            StandardBus sb=(StandardBus) v;
                            String[][] sbArr = sb.getStandardBus();
                            for (int i = 0; i < sb.getRows(); i++) {
                                for (int j = 0; j < 4; j++) {
                                    if (j==2){
                                        FileOut.writeToFile(args[1],"| ", true, false);
                                        FileOut.writeToFile(args[1], sbArr[i][j], true, false);
                                        FileOut.writeToFile(args[1], " ", true, false);

                                    }
                                    else {
                                        FileOut.writeToFile(args[1], sbArr[i][j], true, false);
                                        FileOut.writeToFile(args[1], " ", true, false);
                                    }
                                }
                                FileOut.writeToFile(args[1],"", true, true);
                            }
                            String revenueForPrint=String.format("Revenue: %.2f",sb.getRevenue());
                            FileOut.writeToFile(args[1], revenueForPrint, true, true);
                        } else if (v.getType().equals("Premium")) {
                            PremiumBus pb=(PremiumBus) v;
                            String[][] pbArr = pb.getPremiumBus();
                            for (int i = 0; i < pb.getRows(); i++) {
                                for (int j = 0; j < 3; j++) {
                                    if (j==1){
                                        FileOut.writeToFile(args[1],"| ", true, false);
                                        FileOut.writeToFile(args[1], pbArr[i][j], true, false);
                                        FileOut.writeToFile(args[1], " ", true, false);
                                    }
                                    else {
                                        FileOut.writeToFile(args[1], pbArr[i][j], true, false);
                                        FileOut.writeToFile(args[1], " ", true, false);
                                    }
                                }
                                FileOut.writeToFile(args[1],"", true, true);
                            }
                            String revenueForPrint=String.format("Revenue: %.2f",pb.getRevenue());
                            FileOut.writeToFile(args[1], revenueForPrint, true, true);
                        }
                        else if (v.getType().equals("Minibus")) {
                            Minibus mb=(Minibus) v;
                            String[][] mbArr = mb.getMiniBus();
                            for (int i = 0; i < mb.getRows(); i++) {
                                for (int j = 0; j < 2; j++) {
                                    FileOut.writeToFile(args[1], mbArr[i][j], true, false);
                                    FileOut.writeToFile(args[1], " ", true, false);
                                }
                                FileOut.writeToFile(args[1],"", true, true);
                            }
                            String revenueForPrint=String.format("Revenue: %.2f",mb.getRevenue());
                            FileOut.writeToFile(args[1], revenueForPrint, true, true);
                        }
                        FileOut.writeToFile(args[1], "----------------", true, true);
                    }

                }

                break;
            default:
                // Invalid command
                String fd=String.format("COMMAND: %s",command);
                FileOut.writeToFile(args[1],fd, true, true);
                String a=String.format("ERROR: There is no command namely %s!",command);
                FileOut.writeToFile(args[1], a, true, true);
                break;
        }
    }
}